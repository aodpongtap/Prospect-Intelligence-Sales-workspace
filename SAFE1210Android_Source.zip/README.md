# SAFE1210 Android

Android source project for opening the SAFE1210 online store in a native Android WebView shell.

## Included

- Kotlin Activity and Android WebView
- JavaScript and DOM storage enabled for the existing storefront
- Back navigation, refresh, loading progress, and a retry screen
- HTTPS-only web content; mixed content and local file access are disabled
- `tel:`, `mailto:`, and other non-web links are delegated to Android apps

The app displays the existing website. It does not implement a separate catalog, cart, payment API, or SAFE device-control SDK. Store content and checkout behavior remain subject to the website.

## Build

1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this `SAFE1210Android` folder in Android Studio.
3. Allow Gradle Sync to download the Android Gradle Plugin and Kotlin plugin.
4. Run the `app` configuration on an Android device or emulator, or select **Build > Build APK(s)**.

The current development environment did not have Java, Gradle, or Android SDK installed, so an APK could not be built or tested here.
